/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javainfinite.DAOImpl;

import java.util.ArrayList;
import java.util.List;
import javainfinite.DAO.StudentDao;
import javainfinite.pojo.StudentDetails;
import org.hibernate.Session;
import org.hibernate.Query;
import org.hibernate.Transaction;

/**
 *
 * @author LENOVO
 */
public class StudentDaoImpl implements StudentDao {
    
    @Override
    public void saveStudent (StudentDetails student){
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();
        session.save(student);
        transaction.commit();
        session.close();
    }
    
    
    @Override
    public List<StudentDetails> showAllStudents() {
        List<StudentDetails> studentList = new ArrayList();
        Session session = HibernateUtil.getSessionFactory().openSession();
        Query query = session.createQuery("From StudentDetails");
        studentList = query.list();
        return studentList;
    }
    
    
    @Override
    public void updateStudent(int id, String name, String coursename, String address, String contactno, String emailid, String rollno, String marks, String remarks) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();
        StudentDetails stddetails = (StudentDetails)session.load(StudentDetails.class, id);
        stddetails.setName(name);
        stddetails.setCoursename(coursename);
        stddetails.setAddress(address);
        stddetails.setContactno(contactno);
        stddetails.setEmailid(emailid);
        stddetails.setRollno(rollno);
        stddetails.setMarks(marks);
        stddetails.setRemarks(remarks);
        session.update(stddetails);
        transaction.commit();
        session.close();
    }
    
    
    @Override
     public void deleteStudent(StudentDetails student){
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();
        session.delete(student);
        transaction.commit();
        session.close();
    }   
}
